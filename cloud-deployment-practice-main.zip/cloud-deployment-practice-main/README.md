# React Multi-Stage Docker App

## Build and Run
```bash
docker build -t react-multi-stage .
docker run -p 80:80 react-multi-stage
```

Visit http://localhost to see the app.
